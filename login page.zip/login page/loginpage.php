<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Townsville Community Music Centre </title>

<link href="member.css" rel="stylesheet" type="text/css">
<link href="nav.css" rel="stylesheet" type="text/css">
<link href="rwd.css" rel="stylesheet" type="text/css">
<link href="styles.css" rel="stylesheet" type="text/css">
<script src="member.js"></script>
<script src="nav.js"></script>
<script src="read_more.js"></script>
</head>
<body onLoad="run_first()">
	<?php include("include/nav.inc") ?>

<div class="member-frm">
<form>
    <div class="row">
    	<div class="col-12 col-s-12">
            <h1>Login</h1>
			<p>Please enter your email and password</p>
		</div>
	</div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="email">Email:</label>
            <input type="email" id="email" name="email" 
              size="35" maxlength="50" required />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="password">Password:</label>
            <input type="password" id="password" name="password" 
              size="20" maxlength="20" required />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label>&nbsp;</label>
            <input type="submit" id="submit" value="Submit" />
            <input type="reset" id="reset" value="Clear" />
            <?php 
				if(isset($error)) {
				echo "<p style=\"color: red;\">$error</p>";
				unset($error);
				}
			?>
        </div>
    </div>           
</form>
</div>

</body>
</html>